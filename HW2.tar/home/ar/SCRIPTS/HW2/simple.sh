#!/bin/bash
while true; do
	echo "$(date) Service is running!!!!!!!!!!!!!!!!!!!!!!"
	sleep 10
done

